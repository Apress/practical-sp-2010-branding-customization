﻿The SharePoint Branding kit solution (SharePointBrandingKit.wsp) contains following two Site Collection Features:
1) SharePoint Branding Kit 1: Basic
2) SharePoint Branding Kit 2: Advanced

Upon feature activation, the site's default master page is switched to use a custom master page and upon deactivation, the custom master page is set back to the SharePoint default.

The solution can be deployed by running the accompanying batch file (deploySBK.bat) which runs a PowerShell script (deploySBK.ps1).

The 3 Files deploySBK.bat, deploySBK.ps1, and SharePointBrandingKit.wsp should all reside in the same directory in order for deploySBK.bat to run properly.

When run, deploySBK.bat will install the solution file and deploy the SharePoint Branding kit globally.  If deploySBK.bat is re-run, the solution will be retracted, removed, re-installed, and re-deployed.

After the The SharePoint Branding kit is deployed, go to the root of any site collection and activate either feature listed above via "Site Actions > Site Settings > Site Collection Features."

NOTE:  Both features can be activated but on sites not using SharePoint's publishing feature, you will only be able to switch master pages by activating/deactivating the features.

