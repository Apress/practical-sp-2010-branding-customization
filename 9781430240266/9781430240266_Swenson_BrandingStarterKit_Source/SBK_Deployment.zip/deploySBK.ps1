function Install-Solution([string]$path, [bool]$gac, [bool]$cas, [string]$webApps, [int]$sequence, [string]$deployCA)
{
    $spAdminServiceName = "SPAdminV4"
    
    [string]$name = Split-Path -Path $path -Leaf
    $solution = Get-SPSolution $name -ErrorAction SilentlyContinue

    if ($solution -ne $null -and $sequence -eq 1) {
        #Retract the solution
        if ($solution.Deployed) {
            Write-Host "Retracting solution $name..."
            If ($deployCA.ToLower().StartsWith("yes") -eq $true) {
                $centralAdmin = Get-SPWebApplication -includecentraladministration | where {$_.DisplayName -eq "SharePoint Central Administration v4"} | select Url 
		Uninstall-SPSolution -Identity $solution -WebApplication $centralAdmin.Url -Confirm:$false
		
		Write-Host 'Waiting for job to finish' 
		WaitForJobToFinish 

	    }
            if ($solution.ContainsWebApplicationResource) {
                Uninstall-SPSolution -Identity $solution -AllWebApplications -Confirm:$false
            } else {
                Uninstall-SPSolution -Identity $solution -Confirm:$false
            }
            
            Stop-Service -Name $spAdminServiceName
            Start-SPAdminJob -Verbose
            Start-Service -Name $spAdminServiceName

            #Block until we're sure the solution is no longer deployed.
            do { Start-Sleep 2 } while ((Get-SPSolution $name).Deployed)

        }

        #Delete the solution
        Write-Host "Removing solution $name..."
        Get-SPSolution $name | Remove-SPSolution -Confirm:$false
    }

    if ($sequence -eq 1) {	
        #Add the solution
        Write-Host "Adding solution $name..."
        $solution = Add-SPSolution $path
    }

    #Deploy the solution
    if (!$solution.ContainsWebApplicationResource) {
        Write-Host "Deploying solution $name to the Farm..."
        $solution | Install-SPSolution -GACDeployment:$gac -CASPolicies:$cas -Confirm:$false -force
    } else {
        if ($webApps -eq $null -or $webApps.Length -eq 0) {
            Write-Warning "The solution $name contains web application resources but no web applications were specified to deploy to."
            return
        }
        $webApps | ForEach-Object {
            Write-Host "Deploying solution $name to $_..."
            $solution | Install-SPSolution -GACDeployment:$gac -CASPolicies:$cas -WebApplication $_ -Confirm:$false -force
        }
    }

    Stop-Service -Name $spAdminServiceName
    Start-SPAdminJob -Verbose
    Start-Service -Name $spAdminServiceName

    #Block until we're sure the solution is deployed.
    do { Start-Sleep 2 } while (!((Get-SPSolution $name).Deployed))

}

function WaitForJobToFinish([string]$SolutionFileName)
{ 
    $JobName = "*solution-deployment*$SolutionFileName*"
    $job = Get-SPTimerJob | ?{ $_.Name -like $JobName }
    if ($job -eq $null) 
    {
        Write-Host 'Timer job not found'
    }
    else
    {
        $JobFullName = $job.Name
        Write-Host -NoNewLine "Waiting to finish job $JobFullName"
        
        while ((Get-SPTimerJob $JobFullName) -ne $null) 
        {
            Write-Host -NoNewLine .
            Start-Sleep -Seconds 2
        }
        Write-Host  "Finished waiting for job.."
    }
}

Add-PsSnapin Microsoft.SharePoint.PowerShell

$strName = $args[0]
$strWebApp = $args[1]
$intSequence = $args[2]
$strdeployCA = $args[3]
$strSolutionPath = ".\" + $args[0]	

Install-Solution $strSolutionPath $true $false $strWebApp $intSequence $strdeployCA

Remove-PsSnapin Microsoft.SharePoint.PowerShell